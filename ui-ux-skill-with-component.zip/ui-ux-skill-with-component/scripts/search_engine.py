﻿import math, re, csv, os, sys

class BM25Engine:
    def __init__(self, corpus):
        self.n = len(corpus)
        self.avgdl = sum(len(d) for d in corpus) / self.n if self.n > 0 else 0
        self.tf, self.df, self.idf = [], {}, {}
        for doc in corpus:
            tmp_tf = {}
            for word in doc: tmp_tf[word] = tmp_tf.get(word, 0) + 1
            self.tf.append(tmp_tf)
            for word in tmp_tf.keys(): self.df[word] = self.df.get(word, 0) + 1
        for word, freq in self.df.items():
            self.idf[word] = math.log((self.n - freq + 0.5) / (freq + 0.5) + 1)

    def get_score(self, query, index):
        score = 0
        for word in query:
            if word not in self.tf[index]: continue
            tf = self.tf[index][word]
            score += self.idf[word] * (tf * 2.5) / (tf + 1.5 * (0.25 + 0.75 * len(self.tf[index]) / self.avgdl))
        return score

def search(query_str):
    data_dir = os.path.join(os.path.dirname(__file__), "../data")
    docs, meta = [], []
    if not os.path.exists(data_dir): return "Data missing."
    for f in os.listdir(data_dir):
        if f.endswith(".csv"):
            with open(os.path.join(data_dir, f), 'r', encoding='utf-8-sig') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    search_content = " ".join([v for k, v in row.items() if k and k.startswith('S_')])
                    docs.append(re.findall(r'\w+', search_content.lower()))
                    meta.append({"file": f, "data": row})
    if not docs: return "No data."
    engine = BM25Engine(docs)
    q = re.findall(r'\w+', query_str.lower())
    scores = sorted([(engine.get_score(q, i), i) for i in range(len(docs))], reverse=True)
    res = []
    for s, i in scores[:8]:
        if s > 0:
            payload = {k: v for k, v in meta[i]['data'].items() if k and k.startswith('O_')}
            res.append(f"[Match: {s:.2f}] [Source: {meta[i]['file']}] Payload: {payload}")
    return "\n".join(res) if res else "No specs found."

if __name__ == "__main__":
    print(search(sys.argv[1] if len(sys.argv) > 1 else ""))