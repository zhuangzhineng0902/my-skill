import csv
import sys
import os

# 获取当前脚本所在目录的绝对路径，确保能找到 data 文件夹
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "..", "data")

def search_specs(keyword):
    results = []
    try:
        # 检索颜色
        with open(os.path.join(DATA_DIR, "brand-colors.csv"), 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if keyword.lower() in str(row).lower():
                    results.append(f"[Color] {row['Name']}: {row['Hex']} ({row['Usage']})")

        # 检索组件
        with open(os.path.join(DATA_DIR, "components.csv"), 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if keyword.lower() in str(row).lower():
                    results.append(f"[Component] {row['Internal_Tag']}: {row['Props_Guideline']}")
    except Exception as e:
        return f"Error reading specs: {str(e)}"

    return "\n".join(results) if results else "No specific enterprise rule found."

if __name__ == "__main__":
    query = sys.argv[1] if len(sys.argv) > 1 else ""
    print(search_specs(query))
