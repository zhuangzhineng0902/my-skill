import csv
import sys
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "..", "data")

def query_system(keyword):
    output = []
    files = {
        "brand-colors.csv": "🎨 Colors",
        "typography.csv": "🔤 Typography",
        "spacing.csv": "📏 Spacing",
        "ux-guidelines.csv": "💡 UX Rules",
        "components.csv": "🧩 Components"
    }

    for filename, title in files.items():
        path = os.path.join(DATA_DIR, filename)
        if not os.path.exists(path): continue

        with open(path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            found = [str(row) for row in reader if keyword.lower() in str(row).lower()]
            if found:
                output.append(f"--- {title} ---")
                output.extend(found[:3]) # 仅展示前3条相关规则

    return "\n".join(output) if output else "No specific match. Following general design principles."

if __name__ == "__main__":
    query = sys.argv[1] if len(sys.argv) > 1 else ""
    print(query_system(query))
