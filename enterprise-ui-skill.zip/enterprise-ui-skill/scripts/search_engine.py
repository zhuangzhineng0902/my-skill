
import math
import re
import csv
import os

class BM25:
    def __init__(self, corpus, k1=1.5, b=0.75):
        self.corpus = corpus
        self.k1 = k1
        self.b = b
        self.doc_len = [len(doc) for doc in corpus]
        self.avgdl = sum(self.doc_len) / len(corpus)
        self.n = len(corpus)
        self.tf = []
        self.df = {}
        self.idf = {}
        self._initialize()

    def _initialize(self):
        for doc in self.corpus:
            tmp_tf = {}
            for word in doc:
                tmp_tf[word] = tmp_tf.get(word, 0) + 1
            self.tf.append(tmp_tf)
            for word in tmp_tf.keys():
                self.df[word] = self.df.get(word, 0) + 1
        for word, freq in self.df.items():
            self.idf[word] = math.log((self.n - freq + 0.5) / (freq + 0.5) + 1)

    def get_score(self, query, index):
        score = 0
        doc_tf = self.tf[index]
        for word in query:
            if word not in doc_tf: continue
            score += (self.idf[word] * doc_tf[word] * (self.k1 + 1) / 
                      (doc_tf[word] + self.k1 * (1 - self.b + self.b * self.doc_len[index] / self.avgdl)))
        return score

def tokenize(text):
    return re.findall(r'\w+', text.lower())

def load_data(data_dir):
    documents = []
    metadata = []
    for filename in os.listdir(data_dir):
        if filename.endswith('.csv'):
            with open(os.path.join(data_dir, filename), 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    content = " ".join(row.values())
                    documents.append(tokenize(content))
                    metadata.append({"source": filename, "data": row})
    return documents, metadata

def search(query_str):
    data_dir = os.path.join(os.path.dirname(__file__), "../data")
    docs, meta = load_data(data_dir)
    bm25 = BM25(docs)
    query = tokenize(query_str)
    scores = [(bm25.get_score(query, i), i) for i in range(len(docs))]
    scores.sort(key=lambda x: x[0], reverse=True)

    results = []
    for score, index in scores[:5]: # 返回前5个最相关的规范
        if score > 0:
            item = meta[index]
            results.append(f"[Score: {score:.2f}] Source: {item['source']}\nContent: {item['data']}\n")
    return "\n".join(results) if results else "No matching guidelines found."

if __name__ == "__main__":
    import sys
    query = sys.argv[1] if len(sys.argv) > 1 else ""
    print(search(query))
