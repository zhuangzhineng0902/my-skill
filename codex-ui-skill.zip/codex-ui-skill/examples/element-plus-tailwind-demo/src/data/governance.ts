export type GovernanceTask = {
  id: string;
  requester: string;
  system: string;
  privilege: string;
  risk: "Low" | "Medium" | "High";
  owner: string;
  submittedAt: string;
  status: "Pending Review" | "Policy Check" | "Approved";
};

export type GovernanceEvent = {
  time: string;
  title: string;
  detail: string;
};

export const governanceTasks: GovernanceTask[] = [
  {
    id: "ACC-10482",
    requester: "Wendy Li",
    system: "Billing Core",
    privilege: "Refund approval",
    risk: "High",
    owner: "Risk Ops",
    submittedAt: "09:18",
    status: "Pending Review",
  },
  {
    id: "ACC-10483",
    requester: "Marcus Zhao",
    system: "Data Hub",
    privilege: "Warehouse export",
    risk: "Medium",
    owner: "Platform Admin",
    submittedAt: "09:32",
    status: "Policy Check",
  },
  {
    id: "ACC-10484",
    requester: "Nina Gao",
    system: "Vendor Portal",
    privilege: "Supplier settlement edit",
    risk: "High",
    owner: "Finance Control",
    submittedAt: "09:41",
    status: "Pending Review",
  },
  {
    id: "ACC-10485",
    requester: "Arthur Xu",
    system: "CRM Suite",
    privilege: "Lead reassignment",
    risk: "Low",
    owner: "Sales Ops",
    submittedAt: "10:05",
    status: "Approved",
  },
];

export const governanceEvents: GovernanceEvent[] = [
  {
    time: "09:20",
    title: "Policy engine synced",
    detail: "Updated segregation-of-duty rules were pulled into the approval workflow.",
  },
  {
    time: "09:47",
    title: "High-risk request escalated",
    detail: "Refund approval access for Billing Core routed to dual approvers.",
  },
  {
    time: "10:10",
    title: "Review queue refreshed",
    detail: "Two low-risk requests were auto-approved after entitlement checks passed.",
  },
];
