export type OrderRecord = {
  id: string;
  customer: string;
  region: string;
  status: "Ready" | "Pending" | "Risk";
  amount: string;
  owner: string;
};

export const orders: OrderRecord[] = [
  {
    id: "SO-20391",
    customer: "Bayshore Retail",
    region: "East China",
    status: "Ready",
    amount: "¥128,000",
    owner: "Olivia",
  },
  {
    id: "SO-20392",
    customer: "Northwind Health",
    region: "South China",
    status: "Pending",
    amount: "¥76,500",
    owner: "Mason",
  },
  {
    id: "SO-20393",
    customer: "Lattice Supply",
    region: "North China",
    status: "Risk",
    amount: "¥214,300",
    owner: "Emma",
  },
  {
    id: "SO-20394",
    customer: "Verge Logistics",
    region: "West China",
    status: "Ready",
    amount: "¥64,900",
    owner: "Sophia",
  },
];
