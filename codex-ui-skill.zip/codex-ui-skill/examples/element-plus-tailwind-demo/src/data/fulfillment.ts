export type FulfillmentRecord = {
  orderNo: string;
  account: string;
  channel: string;
  warehouse: string;
  sla: string;
  health: "Healthy" | "Watch" | "Blocked";
  completion: number;
  owner: string;
};

export type FulfillmentAlert = {
  title: string;
  detail: string;
  severity: "High" | "Medium" | "Low";
};

export const fulfillmentRecords: FulfillmentRecord[] = [
  {
    orderNo: "FUL-88031",
    account: "Meridian Stores",
    channel: "Marketplace",
    warehouse: "Shanghai Hub",
    sla: "2h 15m",
    health: "Healthy",
    completion: 92,
    owner: "Irene",
  },
  {
    orderNo: "FUL-88032",
    account: "Nova Health",
    channel: "Direct",
    warehouse: "Suzhou Hub",
    sla: "4h 40m",
    health: "Watch",
    completion: 67,
    owner: "Caleb",
  },
  {
    orderNo: "FUL-88033",
    account: "Peak Mobility",
    channel: "Distributor",
    warehouse: "Ningbo Hub",
    sla: "6h 05m",
    health: "Blocked",
    completion: 41,
    owner: "Mila",
  },
  {
    orderNo: "FUL-88034",
    account: "Luma Living",
    channel: "Marketplace",
    warehouse: "Shenzhen Hub",
    sla: "1h 30m",
    health: "Healthy",
    completion: 96,
    owner: "Noah",
  },
];

export const fulfillmentAlerts: FulfillmentAlert[] = [
  {
    title: "Carrier SLA drift",
    detail: "Ningbo Hub is trending 22% slower than the morning baseline.",
    severity: "High",
  },
  {
    title: "Wave picking queue",
    detail: "42 orders are waiting for allocation in Suzhou after replenishment.",
    severity: "Medium",
  },
  {
    title: "Returns intake",
    detail: "Marketplace returns exceeded the expected intake by 8 orders.",
    severity: "Low",
  },
];
