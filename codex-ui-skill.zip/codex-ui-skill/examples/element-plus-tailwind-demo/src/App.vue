<script setup lang="ts">
import CustomerOrdersPageBefore from "./components/CustomerOrdersPageBefore.vue";
import CustomerOrdersPageAfter from "./components/CustomerOrdersPageAfter.vue";
import EnterpriseGovernanceWorkbench from "./components/EnterpriseGovernanceWorkbench.vue";
import FulfillmentCommandCenterBefore from "./components/FulfillmentCommandCenterBefore.vue";
import FulfillmentCommandCenterAfter from "./components/FulfillmentCommandCenterAfter.vue";
</script>

<template>
  <div class="space-y-10 py-10">
    <section class="mx-auto max-w-[1440px] space-y-3 px-6">
      <p class="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--ccui-color-primary)]">
        Element Plus + Tailwind
      </p>
      <h1 class="text-4xl font-semibold leading-tight text-[var(--ccui-color-text-primary)]">
        Enterprise UI Refiner Demo
      </h1>
      <p class="max-w-3xl text-sm leading-6 text-[var(--ccui-color-text-secondary)]">
        The first panel keeps common enterprise rule violations. The second panel applies the
        refiner workflow and normalizes layout spacing, toolbar composition, and table defaults.
      </p>
    </section>

    <section class="space-y-4">
      <div class="mx-auto max-w-[1440px] px-6">
        <h2 class="text-2xl font-semibold text-[var(--ccui-color-text-primary)]">Before</h2>
      </div>
      <CustomerOrdersPageBefore />
    </section>

    <section class="space-y-4">
      <div class="mx-auto max-w-[1440px] px-6">
        <h2 class="text-2xl font-semibold text-[var(--ccui-color-text-primary)]">After</h2>
      </div>
      <CustomerOrdersPageAfter />
    </section>

    <section class="mx-auto max-w-[1440px] space-y-3 px-6 pt-6">
      <p class="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--ccui-color-primary)]">
        Complex Example
      </p>
      <h2 class="text-3xl font-semibold leading-tight text-[var(--ccui-color-text-primary)]">
        Fulfillment Command Center
      </h2>
      <p class="max-w-4xl text-sm leading-6 text-[var(--ccui-color-text-secondary)]">
        This pair adds a more realistic enterprise page with a summary hero, filter controls,
        workload metrics, a dense operations table, and an exceptions sidebar.
      </p>
    </section>

    <section class="space-y-4">
      <div class="mx-auto max-w-[1440px] px-6">
        <h2 class="text-2xl font-semibold text-[var(--ccui-color-text-primary)]">
          Complex Before
        </h2>
      </div>
      <FulfillmentCommandCenterBefore />
    </section>

    <section class="space-y-4">
      <div class="mx-auto max-w-[1440px] px-6">
        <h2 class="text-2xl font-semibold text-[var(--ccui-color-text-primary)]">
          Complex After
        </h2>
      </div>
      <FulfillmentCommandCenterAfter />
    </section>

    <section class="mx-auto max-w-[1440px] space-y-3 px-6 pt-6">
      <p class="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--ccui-color-primary)]">
        Internal Web System
      </p>
      <h2 class="text-3xl font-semibold leading-tight text-[var(--ccui-color-text-primary)]">
        Enterprise Approval Workbench
      </h2>
      <p class="max-w-4xl text-sm leading-6 text-[var(--ccui-color-text-secondary)]">
        This example is intentionally styled like an internal enterprise console: high information
        density, clear control hierarchy, restrained color usage, and operator-first layout.
      </p>
    </section>

    <section class="space-y-4">
      <div class="mx-auto max-w-[1440px] px-6">
        <h2 class="text-2xl font-semibold text-[var(--ccui-color-text-primary)]">
          Internal System Example
        </h2>
      </div>
      <EnterpriseGovernanceWorkbench />
    </section>
  </div>
</template>
