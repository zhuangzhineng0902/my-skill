<script setup lang="ts">
import { Search } from "@element-plus/icons-vue";
import { orders } from "../data/orders";

const statusTagType = {
  Ready: "success",
  Pending: "warning",
  Risk: "danger",
} as const;
</script>

<template>
  <div class="ccui-page-container min-h-screen py-8">
    <div class="mx-auto max-w-[1320px]">
      <section class="ccui-page-card overflow-hidden p-6">
        <div
          class="mb-6 flex flex-col gap-4 border-b border-[var(--ccui-color-border-default)] pb-6 lg:flex-row lg:items-start lg:justify-between"
        >
          <div class="max-w-3xl space-y-2">
            <p
              class="text-[var(--ccui-font-size-s)] font-semibold uppercase tracking-[0.2em] text-[var(--ccui-color-primary)]"
            >
              Revenue Desk
            </p>
            <h1 class="ccui-section-title ccui-page-title-display">Customer Orders</h1>
            <p class="ccui-section-subtitle">
              Track submitted orders, review fulfillment status, and coordinate next actions.
            </p>
          </div>
          <div
            class="min-w-[180px] rounded-2xl border border-[var(--ccui-color-border-default)] bg-[var(--ccui-color-bg-page)] px-4 py-3"
          >
            <p class="ccui-kpi-label">
              Today Fulfillment
            </p>
            <p class="ccui-kpi-value mt-1 font-semibold">94%</p>
          </div>
        </div>

        <div class="mb-5 flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div class="flex flex-1 flex-wrap items-center gap-[var(--ccui-space-m)]">
            <el-input
              class="!w-[260px]"
              placeholder="Search order or customer"
              :prefix-icon="Search"
            />
            <el-select class="!w-[160px]" placeholder="Status">
              <el-option label="Ready" value="Ready" />
              <el-option label="Pending" value="Pending" />
              <el-option label="Risk" value="Risk" />
            </el-select>
          </div>

          <div class="ccui-table-toolbar-actions">
            <el-button type="primary">Search</el-button>
            <el-button>Reset</el-button>
            <el-button type="success">New Order</el-button>
            <el-button>Export</el-button>
          </div>
        </div>

        <el-table :data="orders" size="medium">
          <el-table-column prop="id" label="Order ID" min-width="120" />
          <el-table-column prop="customer" label="Customer" min-width="180" />
          <el-table-column prop="region" label="Region" min-width="140" />
          <el-table-column prop="status" label="Status" min-width="140">
            <template #default="{ row }">
              <el-tag :type="statusTagType[row.status]" effect="light" round>
                {{ row.status }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="amount" label="Amount" min-width="120" />
          <el-table-column prop="owner" label="Owner" min-width="120" />
        </el-table>
      </section>
    </div>
  </div>
</template>
