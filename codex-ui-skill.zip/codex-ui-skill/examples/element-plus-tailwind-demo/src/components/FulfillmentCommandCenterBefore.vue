<script setup lang="ts">
import { Bell, Search } from "@element-plus/icons-vue";
import { fulfillmentAlerts, fulfillmentRecords } from "../data/fulfillment";

const severityType = {
  High: "danger",
  Medium: "warning",
  Low: "info",
} as const;

const healthType = {
  Healthy: "success",
  Watch: "warning",
  Blocked: "danger",
} as const;
</script>

<template>
  <div class="min-h-screen bg-[#eef3fb] px-[20px] py-8 text-[#172033]">
    <div class="mx-auto max-w-[1440px] space-y-5">
      <div
        class="rounded-[28px] bg-[linear-gradient(135deg,#0f4cdd_0%,#4f7cff_100%)] px-7 py-6 text-white shadow-[0_24px_60px_rgba(18,51,128,0.28)]"
      >
        <div class="flex flex-wrap items-start justify-between gap-5">
          <div class="max-w-3xl">
            <p class="mb-2 text-[12px] font-semibold uppercase tracking-[0.28em] text-[#c8d7ff]">
              Operations Command
            </p>
            <h2 class="mb-2 text-[32px] font-semibold leading-[40px]">Fulfillment Command Center</h2>
            <p class="text-[15px] leading-6 text-[#e8eeff]">
              Monitor warehouse execution, investigate SLA risk, and coordinate exceptions before
              orders miss the ship window.
            </p>
          </div>

          <div class="grid min-w-[320px] grid-cols-3 gap-[14px]">
            <div class="rounded-[20px] bg-[rgba(255,255,255,0.16)] px-4 py-4 backdrop-blur">
              <p class="text-[12px] text-[#dfe8ff]">Orders In Flight</p>
              <p class="mt-2 text-[26px] font-semibold">284</p>
            </div>
            <div class="rounded-[20px] bg-[rgba(255,255,255,0.16)] px-4 py-4 backdrop-blur">
              <p class="text-[12px] text-[#dfe8ff]">At Risk</p>
              <p class="mt-2 text-[26px] font-semibold">19</p>
            </div>
            <div class="rounded-[20px] bg-[rgba(255,255,255,0.16)] px-4 py-4 backdrop-blur">
              <p class="text-[12px] text-[#dfe8ff]">Throughput</p>
              <p class="mt-2 text-[26px] font-semibold">96.3%</p>
            </div>
          </div>
        </div>
      </div>

      <div class="grid gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div class="rounded-[26px] bg-white px-6 py-6 shadow-[0_18px_42px_rgba(15,23,42,0.08)]">
          <div class="mb-5 flex flex-wrap items-center">
            <el-input class="mr-[10px] !w-[240px]" placeholder="Search order or account" :prefix-icon="Search" />
            <el-select class="mr-[18px] !w-[160px]" placeholder="Warehouse">
              <el-option label="Shanghai Hub" value="Shanghai" />
              <el-option label="Suzhou Hub" value="Suzhou" />
              <el-option label="Ningbo Hub" value="Ningbo" />
            </el-select>
            <el-date-picker class="mr-[18px] !w-[220px]" type="daterange" range-separator="To" />
            <el-button type="primary" class="mr-[8px] !rounded-full !bg-[#245dff] !px-5">Apply</el-button>
            <el-button class="mr-[20px] !rounded-full !px-5">Reset</el-button>
            <el-button type="success" class="mr-[8px] !rounded-full !px-5">Assign Wave</el-button>
            <el-button class="!rounded-full !px-5">Export Queue</el-button>
          </div>

          <div class="mb-4 grid gap-[14px] md:grid-cols-3">
            <div class="rounded-[22px] border border-[#ebf0fb] bg-[#f8faff] px-5 py-4">
              <p class="text-[12px] text-[#6a7387]">Average Pick Time</p>
              <p class="mt-2 text-[24px] font-semibold text-[#172033]">18 min</p>
            </div>
            <div class="rounded-[22px] border border-[#ebf0fb] bg-[#f8faff] px-5 py-4">
              <p class="text-[12px] text-[#6a7387]">Dock Load</p>
              <p class="mt-2 text-[24px] font-semibold text-[#172033]">74%</p>
            </div>
            <div class="rounded-[22px] border border-[#ebf0fb] bg-[#f8faff] px-5 py-4">
              <p class="text-[12px] text-[#6a7387]">Return Queue</p>
              <p class="mt-2 text-[24px] font-semibold text-[#172033]">31</p>
            </div>
          </div>

          <el-table :data="fulfillmentRecords" class="rounded-[20px] overflow-hidden">
            <el-table-column prop="orderNo" label="Order No" min-width="130" />
            <el-table-column prop="account" label="Account" min-width="180" />
            <el-table-column prop="channel" label="Channel" min-width="140" />
            <el-table-column prop="warehouse" label="Warehouse" min-width="160" />
            <el-table-column prop="sla" label="SLA Clock" min-width="120" />
            <el-table-column prop="health" label="Health" min-width="120">
              <template #default="{ row }">
                <el-tag :type="healthType[row.health]" effect="light" round>
                  {{ row.health }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="Completion" min-width="180">
              <template #default="{ row }">
                <div class="flex items-center gap-[10px]">
                  <el-progress :stroke-width="10" :percentage="row.completion" />
                  <span class="text-[13px] text-[#5d6779]">{{ row.completion }}%</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="owner" label="Owner" min-width="120" />
          </el-table>
        </div>

        <aside class="rounded-[26px] bg-white px-5 py-5 shadow-[0_18px_42px_rgba(15,23,42,0.08)]">
          <div class="mb-4 flex items-center justify-between">
            <div>
              <p class="text-[12px] font-semibold uppercase tracking-[0.22em] text-[#4f7cff]">Alert feed</p>
              <h3 class="mt-2 text-[22px] font-semibold text-[#172033]">Exceptions</h3>
            </div>
            <el-button circle class="!border-[#d8e1f2]">
              <el-icon><Bell /></el-icon>
            </el-button>
          </div>

          <div class="space-y-[14px]">
            <div
              v-for="alert in fulfillmentAlerts"
              :key="alert.title"
              class="rounded-[20px] border border-[#edf2fb] bg-[#f8faff] px-4 py-4"
            >
              <div class="mb-3 flex items-center justify-between gap-3">
                <p class="text-[14px] font-semibold text-[#172033]">{{ alert.title }}</p>
                <el-tag :type="severityType[alert.severity]" effect="light" round>
                  {{ alert.severity }}
                </el-tag>
              </div>
              <p class="text-[13px] leading-6 text-[#697386]">{{ alert.detail }}</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  </div>
</template>
