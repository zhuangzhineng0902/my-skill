<script setup lang="ts">
import { Bell, Search } from "@element-plus/icons-vue";
import { fulfillmentAlerts, fulfillmentRecords } from "../data/fulfillment";

const severityType = {
  High: "danger",
  Medium: "warning",
  Low: "info",
} as const;

const healthType = {
  Healthy: "success",
  Watch: "warning",
  Blocked: "danger",
} as const;

const summaryCards = [
  { label: "Orders In Flight", value: "284" },
  { label: "At Risk", value: "19" },
  { label: "Throughput", value: "96.3%" },
];

const secondaryMetrics = [
  { label: "Average Pick Time", value: "18 min" },
  { label: "Dock Load", value: "74%" },
  { label: "Return Queue", value: "31" },
];
</script>

<template>
  <div class="ccui-page-container min-h-screen py-8">
    <div class="mx-auto max-w-[1440px] space-y-5">
      <section class="ccui-command-hero">
        <div class="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
          <div class="max-w-3xl space-y-2">
            <p class="ccui-hero-eyebrow">Operations Command</p>
            <h2 class="ccui-hero-title">Fulfillment Command Center</h2>
            <p class="ccui-hero-subtitle">
              Monitor warehouse execution, investigate SLA risk, and coordinate exceptions before
              orders miss the ship window.
            </p>
          </div>

          <div class="grid min-w-[320px] gap-[var(--ccui-space-m)] sm:grid-cols-3">
            <div
              v-for="card in summaryCards"
              :key="card.label"
              class="ccui-hero-metric-card"
            >
              <p class="ccui-hero-metric-label">{{ card.label }}</p>
              <p class="ccui-hero-metric-value">{{ card.value }}</p>
            </div>
          </div>
        </div>
      </section>

      <div class="grid gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
        <section class="ccui-page-card p-6">
          <div class="mb-5 flex flex-col gap-4 border-b border-[var(--ccui-color-border-default)] pb-5">
            <div class="flex flex-col gap-2">
              <h3 class="ccui-section-title ccui-subsection-title">Execution Queue</h3>
              <p class="ccui-section-subtitle">
                Filter the active fulfillment workload and assign actions before SLA breaches grow.
              </p>
            </div>

            <div class="flex flex-col gap-4 2xl:flex-row 2xl:items-center 2xl:justify-between">
              <div class="flex flex-1 flex-wrap items-center gap-[var(--ccui-space-m)]">
                <el-input
                  class="!w-[240px]"
                  placeholder="Search order or account"
                  :prefix-icon="Search"
                />
                <el-select class="!w-[160px]" placeholder="Warehouse">
                  <el-option label="Shanghai Hub" value="Shanghai" />
                  <el-option label="Suzhou Hub" value="Suzhou" />
                  <el-option label="Ningbo Hub" value="Ningbo" />
                </el-select>
                <el-date-picker class="!w-[220px]" type="daterange" range-separator="To" />
              </div>

              <div class="ccui-table-toolbar-actions">
                <el-button type="primary">Apply</el-button>
                <el-button>Reset</el-button>
                <el-button type="success">Assign Wave</el-button>
                <el-button>Export Queue</el-button>
              </div>
            </div>
          </div>

          <div class="mb-5 grid gap-[var(--ccui-space-m)] md:grid-cols-3">
            <div
              v-for="metric in secondaryMetrics"
              :key="metric.label"
              class="ccui-surface-metric-card"
            >
              <p class="ccui-kpi-label">{{ metric.label }}</p>
              <p class="ccui-surface-metric-value">{{ metric.value }}</p>
            </div>
          </div>

          <el-table :data="fulfillmentRecords" size="medium">
            <el-table-column prop="orderNo" label="Order No" min-width="130" />
            <el-table-column prop="account" label="Account" min-width="180" />
            <el-table-column prop="channel" label="Channel" min-width="140" />
            <el-table-column prop="warehouse" label="Warehouse" min-width="160" />
            <el-table-column prop="sla" label="SLA Clock" min-width="120" />
            <el-table-column prop="health" label="Health" min-width="120">
              <template #default="{ row }">
                <el-tag :type="healthType[row.health]" effect="light" round>
                  {{ row.health }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="Completion" min-width="180">
              <template #default="{ row }">
                <div class="flex items-center gap-[var(--ccui-space-m)]">
                  <el-progress :stroke-width="10" :percentage="row.completion" />
                  <span class="ccui-table-inline-value">{{ row.completion }}%</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="owner" label="Owner" min-width="120" />
          </el-table>
        </section>

        <aside class="ccui-page-card p-5">
          <div class="mb-4 flex items-center justify-between">
            <div class="space-y-2">
              <p class="ccui-alert-eyebrow">Alert feed</p>
              <h3 class="ccui-section-title ccui-subsection-title">Exceptions</h3>
            </div>
            <el-button circle>
              <el-icon><Bell /></el-icon>
            </el-button>
          </div>

          <div class="space-y-[var(--ccui-space-m)]">
            <div
              v-for="alert in fulfillmentAlerts"
              :key="alert.title"
              class="ccui-alert-card"
            >
              <div class="mb-3 flex items-center justify-between gap-3">
                <p class="ccui-alert-title">{{ alert.title }}</p>
                <el-tag :type="severityType[alert.severity]" effect="light" round>
                  {{ alert.severity }}
                </el-tag>
              </div>
              <p class="ccui-alert-detail">{{ alert.detail }}</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  </div>
</template>
