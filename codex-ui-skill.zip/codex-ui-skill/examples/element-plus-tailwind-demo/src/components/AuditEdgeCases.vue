<script setup lang="ts">
const dynamicCardClass =
  "bg-[#ffffff] text-[15px] px-[18px] py-[10px] border-[#d9e2f2]";

const metricStyle = {
  color: "#245dff",
  padding: "12px 18px",
  lineHeight: "20px",
};
</script>

<template>
  <section class="px-[24px] py-6">
    <div
      :class="dynamicCardClass"
      style="background-color: #f5f8ff; padding: 12px 16px; font-size: 15px;"
    >
      Dynamic card
    </div>

    <el-button
      :style="metricStyle"
      class="mt-4"
    >
      Styled Button
    </el-button>
  </section>
</template>

<style scoped>
.metric-panel :deep(.el-button) {
  color: #1f2329 !important;
  padding: 10px 18px;
}
</style>
