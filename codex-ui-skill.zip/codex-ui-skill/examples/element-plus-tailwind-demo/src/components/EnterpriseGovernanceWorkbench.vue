<script setup lang="ts">
import { Lock, Search, Warning } from "@element-plus/icons-vue";
import { governanceEvents, governanceTasks } from "../data/governance";

const riskTagType = {
  Low: "success",
  Medium: "warning",
  High: "danger",
} as const;

const statusTagType = {
  "Pending Review": "danger",
  "Policy Check": "warning",
  Approved: "success",
} as const;

const queueStats = [
  { label: "Open requests", value: "42", hint: "+6 from previous hour" },
  { label: "High-risk reviews", value: "8", hint: "3 need dual approval" },
  { label: "Auto-approved", value: "17", hint: "Rules passed in under 2 min" },
];

const systemHealth = [
  { label: "Policy coverage", value: "98.6%" },
  { label: "Median review time", value: "14 min" },
  { label: "Escalation rate", value: "6.2%" },
];
</script>

<template>
  <div class="ccui-page-container min-h-screen py-8">
    <div class="mx-auto max-w-[1440px] space-y-5">
      <section class="ccui-page-card p-6">
        <div class="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
          <div class="max-w-3xl space-y-2">
            <div class="ccui-workbench-badge">
              <el-icon><Lock /></el-icon>
              <span>Access Governance</span>
            </div>
            <h2 class="ccui-page-title-display">Enterprise Approval Workbench</h2>
            <p class="ccui-section-subtitle">
              Review privileged access requests, inspect policy decisions, and route exceptions
              through the control workflow without leaving the operations console.
            </p>
          </div>

          <div class="grid gap-[var(--ccui-space-m)] md:grid-cols-3">
            <div
              v-for="stat in queueStats"
              :key="stat.label"
              class="ccui-governance-stat-card"
            >
              <p class="ccui-kpi-label">{{ stat.label }}</p>
              <p class="ccui-governance-stat-value">{{ stat.value }}</p>
              <p class="ccui-governance-stat-hint">{{ stat.hint }}</p>
            </div>
          </div>
        </div>
      </section>

      <div class="grid gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
        <section class="ccui-page-card p-6">
          <div class="mb-5 flex flex-col gap-4 border-b border-[var(--ccui-color-border-default)] pb-5">
            <div class="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div class="space-y-2">
                <h3 class="ccui-section-title ccui-subsection-title">Approval Queue</h3>
                <p class="ccui-section-subtitle">
                  Prioritize pending requests by risk level, system sensitivity, and owner load.
                </p>
              </div>

              <div class="ccui-workbench-tabs">
                <button class="ccui-workbench-tab ccui-workbench-tab-active" type="button">
                  Pending
                </button>
                <button class="ccui-workbench-tab" type="button">Escalated</button>
                <button class="ccui-workbench-tab" type="button">Completed</button>
              </div>
            </div>

            <div class="flex flex-col gap-4 2xl:flex-row 2xl:items-center 2xl:justify-between">
              <div class="flex flex-1 flex-wrap items-center gap-[var(--ccui-space-m)]">
                <el-input
                  class="!w-[240px]"
                  placeholder="Search request or requester"
                  :prefix-icon="Search"
                />
                <el-select class="!w-[180px]" placeholder="System">
                  <el-option label="Billing Core" value="billing" />
                  <el-option label="Data Hub" value="data-hub" />
                  <el-option label="CRM Suite" value="crm" />
                </el-select>
                <el-select class="!w-[160px]" placeholder="Risk">
                  <el-option label="High" value="High" />
                  <el-option label="Medium" value="Medium" />
                  <el-option label="Low" value="Low" />
                </el-select>
              </div>

              <div class="ccui-table-toolbar-actions">
                <el-button type="primary">Run Policy Check</el-button>
                <el-button>Assign Reviewer</el-button>
                <el-button>Export</el-button>
              </div>
            </div>
          </div>

          <div class="mb-5 grid gap-[var(--ccui-space-m)] md:grid-cols-3">
            <div
              v-for="metric in systemHealth"
              :key="metric.label"
              class="ccui-surface-metric-card"
            >
              <p class="ccui-kpi-label">{{ metric.label }}</p>
              <p class="ccui-surface-metric-value">{{ metric.value }}</p>
            </div>
          </div>

          <el-table :data="governanceTasks" size="medium">
            <el-table-column prop="id" label="Request ID" min-width="120" />
            <el-table-column prop="requester" label="Requester" min-width="140" />
            <el-table-column prop="system" label="System" min-width="150" />
            <el-table-column prop="privilege" label="Privilege" min-width="180" />
            <el-table-column prop="risk" label="Risk" min-width="100">
              <template #default="{ row }">
                <el-tag :type="riskTagType[row.risk]" effect="light" round>
                  {{ row.risk }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="owner" label="Owner" min-width="140" />
            <el-table-column prop="submittedAt" label="Submitted" min-width="100" />
            <el-table-column prop="status" label="Status" min-width="130">
              <template #default="{ row }">
                <el-tag :type="statusTagType[row.status]" effect="light" round>
                  {{ row.status }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
        </section>

        <aside class="ccui-page-card p-5">
          <div class="mb-4 flex items-start justify-between gap-3">
            <div class="space-y-2">
              <p class="ccui-alert-eyebrow">Control feed</p>
              <h3 class="ccui-section-title ccui-subsection-title">Policy Timeline</h3>
            </div>
            <div class="ccui-control-pill">
              <el-icon><Warning /></el-icon>
              <span>2 escalations</span>
            </div>
          </div>

          <div class="space-y-[var(--ccui-space-m)]">
            <div
              v-for="event in governanceEvents"
              :key="event.time + event.title"
              class="ccui-timeline-card"
            >
              <p class="ccui-timeline-time">{{ event.time }}</p>
              <p class="ccui-alert-title">{{ event.title }}</p>
              <p class="ccui-alert-detail">{{ event.detail }}</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  </div>
</template>
