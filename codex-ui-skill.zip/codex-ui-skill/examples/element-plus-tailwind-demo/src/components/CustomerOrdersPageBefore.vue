<script setup lang="ts">
import { Search } from "@element-plus/icons-vue";
import { orders } from "../data/orders";
</script>

<template>
  <div class="min-h-screen bg-[#f3f6fb] px-[18px] py-7 text-[#1f2329]">
    <div class="mx-auto max-w-[1320px]">
      <div class="mb-5 rounded-[24px] bg-white px-6 py-5 shadow-[0_18px_40px_rgba(15,23,42,0.08)]">
        <div class="mb-5 flex flex-wrap items-start justify-between gap-y-4">
          <div>
            <p class="mb-2 text-[13px] font-semibold uppercase tracking-[0.24em] text-[#4f7cff]">
              Revenue Desk
            </p>
            <h1 class="mb-2 text-[30px] font-semibold leading-[38px] text-[#111827]">
              Customer Orders
            </h1>
            <p class="text-[15px] leading-6 text-[#6b7280]">
              Track submitted orders, review fulfillment status, and coordinate next actions.
            </p>
          </div>
          <div class="rounded-full bg-[#eef4ff] px-4 py-3 text-right">
            <p class="text-[12px] font-medium text-[#6b7280]">Today Fulfillment</p>
            <p class="text-[28px] font-semibold text-[#2563eb]">94%</p>
          </div>
        </div>

        <div class="mb-4 flex flex-wrap items-center">
          <el-input
            class="mr-[10px] !w-[240px]"
            placeholder="Search order or customer"
            :prefix-icon="Search"
          />
          <el-select class="mr-[22px] !w-[160px]" placeholder="Status">
            <el-option label="Ready" value="Ready" />
            <el-option label="Pending" value="Pending" />
            <el-option label="Risk" value="Risk" />
          </el-select>
          <el-button type="primary" class="mr-[6px] !rounded-full !bg-[#245dff] !px-5">
            Search
          </el-button>
          <el-button class="mr-[18px] !rounded-full !border-[#c9d2f0] !px-5">Reset</el-button>
          <el-button type="success" class="mr-[8px] !rounded-full !px-5">New Order</el-button>
          <el-button class="!rounded-full !px-5">Export</el-button>
        </div>

        <el-table :data="orders" class="rounded-[20px] overflow-hidden">
          <el-table-column prop="id" label="Order ID" min-width="120" />
          <el-table-column prop="customer" label="Customer" min-width="180" />
          <el-table-column prop="region" label="Region" min-width="140" />
          <el-table-column prop="status" label="Status" min-width="140">
            <template #default="{ row }">
              <el-tag
                :type="row.status === 'Risk' ? 'danger' : row.status === 'Pending' ? 'warning' : 'success'"
                effect="light"
                round
              >
                {{ row.status }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="amount" label="Amount" min-width="120" />
          <el-table-column prop="owner" label="Owner" min-width="120" />
        </el-table>
      </div>
    </div>
  </div>
</template>
