# Element Plus Tailwind Enterprise Demo

This demo contains:

- `src/components/CustomerOrdersPageBefore.vue`: a page with intentional enterprise UI rule violations.
- `src/components/CustomerOrdersPageAfter.vue`: the same page refactored with the `enterprise-ui-ux-refiner` workflow.
- `../../enterprise-ui-ux-refiner/scripts/audit_example.py`: a lightweight validator that compares rule signals between the two files.
- `../../enterprise-ui-ux-refiner/scripts/audit_vue_page.py`: a generic page auditor that flags likely enterprise rule violations in `.vue` files.

Run locally:

```bash
npm install
npm run dev
```

Audit locally:

```bash
python3 ../../enterprise-ui-ux-refiner/scripts/audit_vue_page.py src/components/CustomerOrdersPageBefore.vue
python3 ../../enterprise-ui-ux-refiner/scripts/audit_vue_page.py src/components/CustomerOrdersPageAfter.vue
python3 ../../enterprise-ui-ux-refiner/scripts/audit_example.py
```
