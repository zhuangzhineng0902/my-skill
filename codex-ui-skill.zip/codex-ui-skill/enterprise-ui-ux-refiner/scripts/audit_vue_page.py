#!/usr/bin/env python3
"""Heuristic enterprise UI audit for Vue pages."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_STYLE_CANDIDATES = (
    "src/style.css",
    "src/styles.css",
    "src/assets/styles.css",
    "src/assets/main.css",
    "src/main.css",
)

HEX_PATTERN = re.compile(r"(?:#(?:[0-9a-fA-F]{6,8}|[0-9a-fA-F]{3}))")
ARBITRARY_COLOR_PATTERN = re.compile(r"(?:^|[\s\"'])!?((?:bg|text|border|from|to)-\[#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6,8})\])")
ARBITRARY_TEXT_PATTERN = re.compile(r"(?:^|[\s\"'])(text-\[\d+px\]|leading-\[\d+px\])")
ARBITRARY_SPACE_PATTERN = re.compile(r"(?:^|[\s\"'])(?:m|mx|my|mt|mr|mb|ml|p|px|py|pt|pr|pb|pl|gap)-\[\d+px\]")
BUTTON_MARGIN_PATTERN = re.compile(r"<el-button[^>]*class=\"[^\"]*(mr-\[\d+px\])[^\"]*\"", re.IGNORECASE)
TABLE_PATTERN = re.compile(r"<el-table\b([^>]*)>", re.IGNORECASE)
TABLE_MEDIUM_PATTERN = re.compile(r'\bsize\s*=\s*"medium"')
STYLE_BLOCK_PATTERN = re.compile(r"<style\b[^>]*>(.*?)</style>", re.IGNORECASE | re.DOTALL)
INLINE_STYLE_ATTR_PATTERN = re.compile(r'\bstyle\s*=\s*"([^"]+)"')
BIND_STYLE_ATTR_PATTERN = re.compile(r'(?:\:style|v-bind:style)\s*=\s*"([^"]+)"')
BIND_CLASS_ATTR_PATTERN = re.compile(r'(?:\:class|v-bind:class)\s*=\s*"([^"]+)"')
CLASS_STRING_TOKEN_PATTERN = re.compile(
    r"(bg-\[#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6,8})\]|text-\[#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6,8})\]|border-\[#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6,8})\]|text-\[\d+px\]|leading-\[\d+px\]|(?:m|mx|my|mt|mr|mb|ml|p|px|py|pt|pr|pb|pl|gap)-\[\d+px\])"
)
INLINE_COLOR_DECL_PATTERN = re.compile(
    r"(?:color|background(?:-color)?|border-color)\s*:\s*(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\))",
    re.IGNORECASE,
)
INLINE_SPACE_DECL_PATTERN = re.compile(
    r"(?:margin(?:-[a-z]+)?|padding(?:-[a-z]+)?|gap)\s*:\s*([^;]+)",
    re.IGNORECASE,
)
INLINE_TYPE_DECL_PATTERN = re.compile(
    r"(?:font-size|line-height)\s*:\s*([^;]+)",
    re.IGNORECASE,
)
STYLE_OVERRIDE_PATTERN = re.compile(r"(:deep\(|!important\b|\.el-[\w-]+|--el-[\w-]+)")
SCRIPT_COLOR_DECL_PATTERN = re.compile(
    r"(?:color|backgroundColor|background|borderColor)\s*:\s*[\"'](#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\))[\"']",
    re.IGNORECASE,
)
SCRIPT_SPACE_DECL_PATTERN = re.compile(
    r"(?:margin(?:[A-Z][a-zA-Z]+)?|padding(?:[A-Z][a-zA-Z]+)?|gap)\s*:\s*[\"']([^\"']+)[\"']",
    re.IGNORECASE,
)
SCRIPT_TYPE_DECL_PATTERN = re.compile(
    r"(?:fontSize|lineHeight)\s*:\s*[\"']([^\"']+)[\"']",
    re.IGNORECASE,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit a Vue page against enterprise-ui-ux-refiner heuristics."
    )
    parser.add_argument("target", help="Path to a .vue file to audit.")
    parser.add_argument(
        "--style-file",
        action="append",
        dest="style_files",
        help="Optional style files to inspect for shared tokens and wrappers.",
    )
    parser.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="Output format.",
    )
    return parser.parse_args()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def extract_style_blocks(source: str) -> str:
    return "\n".join(match.group(1) for match in STYLE_BLOCK_PATTERN.finditer(source))


def detect_style_files(target: Path, explicit_paths: list[str] | None) -> list[Path]:
    if explicit_paths:
        return [Path(path).resolve() for path in explicit_paths]

    workspace = target.parent
    for parent in (workspace, *workspace.parents):
        matches = [parent / candidate for candidate in DEFAULT_STYLE_CANDIDATES]
        existing = [candidate for candidate in matches if candidate.exists()]
        if existing:
            return existing
    return []


def lines_with_patterns(text: str, patterns: list[re.Pattern[str]]) -> list[dict[str, str | int]]:
    findings: list[dict[str, str | int]] = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        hits: list[str] = []
        for pattern in patterns:
            for match in pattern.finditer(line):
                token = match.group(1) if match.groups() else match.group(0)
                hits.append(token.strip())
        if hits:
            findings.append({"line": lineno, "snippet": line.strip(), "hits": ", ".join(hits)})
    return findings


def find_attribute_evidence(
    source: str,
    attribute_pattern: re.Pattern[str],
    token_pattern: re.Pattern[str],
) -> list[dict[str, str | int]]:
    findings: list[dict[str, str | int]] = []
    for lineno, line in enumerate(source.splitlines(), start=1):
        attribute_match = attribute_pattern.search(line)
        if not attribute_match:
            continue
        value = attribute_match.group(1)
        hits = [match.group(1) if match.groups() else match.group(0) for match in token_pattern.finditer(value)]
        if hits:
            findings.append({"line": lineno, "snippet": line.strip(), "hits": ", ".join(hits)})
    return findings


def find_inline_style_evidence(
    source: str,
    declaration_pattern: re.Pattern[str],
) -> list[dict[str, str | int]]:
    findings: list[dict[str, str | int]] = []
    for lineno, line in enumerate(source.splitlines(), start=1):
        match = INLINE_STYLE_ATTR_PATTERN.search(line)
        if not match:
            continue
        style_value = match.group(1)
        hits = [hit.group(0).strip() for hit in declaration_pattern.finditer(style_value)]
        if hits:
            findings.append({"line": lineno, "snippet": line.strip(), "hits": ", ".join(hits)})
    return findings


def has_shared_page_container(template_text: str, style_text: str) -> bool:
    return "ccui-page-container" in template_text and ".ccui-page-container" in style_text


def audit(target: Path, style_files: list[Path]) -> dict[str, object]:
    source = read_text(target)
    local_style_text = extract_style_blocks(source)
    style_text = "\n".join(
        [local_style_text, *[read_text(path) for path in style_files if path.exists()]]
    )

    findings: list[dict[str, object]] = []

    color_hits = lines_with_patterns(source, [ARBITRARY_COLOR_PATTERN])
    color_hits.extend(find_attribute_evidence(source, BIND_CLASS_ATTR_PATTERN, CLASS_STRING_TOKEN_PATTERN))
    color_hits.extend(find_inline_style_evidence(source, INLINE_COLOR_DECL_PATTERN))
    color_hits.extend(lines_with_patterns(source, [SCRIPT_COLOR_DECL_PATTERN]))
    color_hits.extend(lines_with_patterns(local_style_text, [HEX_PATTERN]))
    if color_hits:
        findings.append(
            {
                "rule_id": "FDN-001",
                "severity": "warning",
                "title": "Hard-coded semantic colors found",
                "reason": "Enterprise colors should come from semantic tokens rather than arbitrary Tailwind color literals.",
                "recommendation": "Replace color literals with --ccui-color-* tokens or utilities backed by shared tokens.",
                "evidence": color_hits,
            }
        )

    type_hits = lines_with_patterns(source, [ARBITRARY_TEXT_PATTERN])
    type_hits.extend(find_attribute_evidence(source, BIND_CLASS_ATTR_PATTERN, CLASS_STRING_TOKEN_PATTERN))
    type_hits.extend(find_inline_style_evidence(source, INLINE_TYPE_DECL_PATTERN))
    type_hits.extend(lines_with_patterns(source, [SCRIPT_TYPE_DECL_PATTERN]))
    type_hits.extend(
        lines_with_patterns(
            local_style_text,
            [
                re.compile(r"(font-size\s*:\s*[^;]+)", re.IGNORECASE),
                re.compile(r"(line-height\s*:\s*[^;]+)", re.IGNORECASE),
            ],
        )
    )
    if type_hits:
        findings.append(
            {
                "rule_id": "FDN-005",
                "severity": "warning",
                "title": "Ad hoc typography scale found",
                "reason": "Font sizes and line heights should come from a shared enterprise scale.",
                "recommendation": "Move repeated display and body sizes to shared typography tokens or wrapper classes.",
                "evidence": type_hits,
            }
        )

    space_hits = lines_with_patterns(source, [ARBITRARY_SPACE_PATTERN])
    space_hits.extend(find_attribute_evidence(source, BIND_CLASS_ATTR_PATTERN, CLASS_STRING_TOKEN_PATTERN))
    space_hits.extend(find_inline_style_evidence(source, INLINE_SPACE_DECL_PATTERN))
    space_hits.extend(lines_with_patterns(source, [SCRIPT_SPACE_DECL_PATTERN]))
    space_hits.extend(
        lines_with_patterns(
            local_style_text,
            [
                re.compile(r"(?:margin(?:-[a-z]+)?\s*:\s*[^;]+)", re.IGNORECASE),
                re.compile(r"(?:padding(?:-[a-z]+)?\s*:\s*[^;]+)", re.IGNORECASE),
                re.compile(r"(?:gap\s*:\s*[^;]+)", re.IGNORECASE),
            ],
        )
    )
    if space_hits:
        findings.append(
            {
                "rule_id": "FDN-006",
                "severity": "warning",
                "title": "Literal spacing utilities found",
                "reason": "Repeated spacing values should come from shared spacing tokens rather than one-off arbitrary utilities.",
                "recommendation": "Replace repeated spacing literals with --ccui-space-* tokens or shared wrapper classes.",
                "evidence": space_hits,
            }
        )

    tables = TABLE_PATTERN.findall(source)
    if tables and not any(TABLE_MEDIUM_PATTERN.search(attrs) for attrs in tables):
        findings.append(
            {
                "rule_id": "CMP-001",
                "severity": "warning",
                "title": "Table size is not explicitly normalized",
                "reason": "Enterprise tables should explicitly opt into medium size when supported by the component API.",
                "recommendation": 'Add `size="medium"` to `el-table` or normalize the shared table wrapper.',
                "evidence": [{"line": entry["line"], "snippet": entry["snippet"], "hits": "el-table"} for entry in lines_with_patterns(source, [TABLE_PATTERN])],
            }
        )

    button_margin_hits = lines_with_patterns(source, [BUTTON_MARGIN_PATTERN])
    if button_margin_hits and "ccui-table-toolbar-actions" not in source:
        findings.append(
            {
                "rule_id": "CMP-003",
                "severity": "warning",
                "title": "Toolbar buttons use one-off margin spacing",
                "reason": "Toolbar actions should use a shared 12px gap wrapper instead of per-button margins.",
                "recommendation": "Wrap related actions in a shared toolbar container such as `.ccui-table-toolbar-actions` backed by --ccui-space-m.",
                "evidence": button_margin_hits,
            }
        )

    safe_margin_hit = bool(re.search(r"(?:^|[\s\"'])px-\[(?:18|24|32)px\]", source))
    if safe_margin_hit and not has_shared_page_container(source, style_text):
        findings.append(
            {
                "rule_id": "LAY-001",
                "severity": "warning",
                "title": "Page safe margin is local instead of shared",
                "reason": "Main content edge spacing should be enforced by a shared page container.",
                "recommendation": "Move horizontal page padding into a shared wrapper such as `.ccui-page-container` and back it with --ccui-space-l.",
                "evidence": lines_with_patterns(source, [re.compile(r"(?:^|[\s\"'])(px-\[(?:18|24|32)px\])")]),
            }
        )

    dynamic_style_hits = lines_with_patterns(source, [BIND_STYLE_ATTR_PATTERN, BIND_CLASS_ATTR_PATTERN])
    if dynamic_style_hits:
        findings.append(
            {
                "rule_id": "FDN-900",
                "severity": "info",
                "title": "Dynamic class or style bindings need manual review",
                "reason": "Bound class/style expressions may assemble arbitrary values or override shared rules at runtime.",
                "recommendation": "Inspect `:class` and `:style` expressions to confirm they resolve to shared tokens, stable wrappers, or approved component props.",
                "evidence": dynamic_style_hits,
            }
        )

    override_hits = lines_with_patterns(local_style_text, [STYLE_OVERRIDE_PATTERN])
    if override_hits:
        findings.append(
            {
                "rule_id": "CMP-900",
                "severity": "info",
                "title": "Component override selectors detected",
                "reason": "Deep selectors, `!important`, and direct Element Plus overrides can hide enterprise-rule violations or create fragile local patches.",
                "recommendation": "Review whether the override belongs in a shared primitive, token layer, or wrapper instead of a local CSS override.",
                "evidence": override_hits,
            }
        )

    if has_shared_page_container(source, style_text) and "@media" not in style_text:
        findings.append(
            {
                "rule_id": "LAY-004",
                "severity": "info",
                "title": "Compact viewport safe margin is not explicit",
                "reason": "Shared page containers should define narrow viewport behavior when the compact system spacing differs from desktop.",
                "recommendation": "Add an explicit mobile safe-margin rule or document why the desktop margin also applies on small screens.",
                "evidence": [{"line": 0, "snippet": "shared page container detected without responsive override", "hits": "ccui-page-container"}],
            }
        )

    summary = {
        "target": str(target),
        "style_files": [str(path) for path in style_files],
        "embedded_style_blocks": bool(local_style_text.strip()),
        "total_findings": len(findings),
        "rule_ids": [finding["rule_id"] for finding in findings],
    }
    return {"summary": summary, "findings": findings}


def as_text(report: dict[str, object]) -> str:
    summary = report["summary"]
    findings = report["findings"]
    lines = [
        "Audit summary:",
        f"  target: {summary['target']}",
        f"  style_files: {', '.join(summary['style_files']) if summary['style_files'] else 'none'}",
        f"  total_findings: {summary['total_findings']}",
    ]
    if not findings:
        lines.append("")
        lines.append("No heuristic findings.")
        return "\n".join(lines)

    for finding in findings:
        lines.append("")
        lines.append(f"[{finding['severity'].upper()}] {finding['rule_id']} {finding['title']}")
        lines.append(f"  reason: {finding['reason']}")
        lines.append(f"  recommendation: {finding['recommendation']}")
        evidence = finding.get("evidence", [])
        for entry in evidence[:5]:
            lines.append(
                f"  evidence: line {entry['line']} | hits: {entry['hits']} | {entry['snippet']}"
            )
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    target = Path(args.target).resolve()
    if not target.exists():
        raise SystemExit(f"Target not found: {target}")

    style_files = detect_style_files(target, args.style_files)
    report = audit(target, style_files)

    if args.format == "json":
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(as_text(report))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
