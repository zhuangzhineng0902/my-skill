#!/usr/bin/env python3
"""Query structured enterprise UI rules stored as CSV files."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RULE_FILES = {
    "foundation": DATA_DIR / "foundation-rules.csv",
    "component": DATA_DIR / "component-rules.csv",
    "layout": DATA_DIR / "global-layout-rules.csv",
}
SEARCH_FIELDS = (
    "rule_id",
    "domain",
    "topic",
    "title",
    "applies_to",
    "keywords",
    "requirement",
    "preferred_pattern",
    "anti_pattern",
    "token_refs",
    "default_value",
    "notes",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Retrieve enterprise UI rules by family, topic, applies-to text, or free-text keywords."
    )
    parser.add_argument(
        "--family",
        action="append",
        choices=sorted(RULE_FILES),
        help="Rule family to search. May be provided multiple times. Defaults to all families.",
    )
    parser.add_argument(
        "--topic",
        action="append",
        help="Match topic substrings such as color, typography, toolbar, or page-safe-margin.",
    )
    parser.add_argument(
        "--applies-to",
        action="append",
        dest="applies_to",
        help="Match applies_to substrings such as table, toolbar, or page shell.",
    )
    parser.add_argument(
        "--keyword",
        action="append",
        help="Free-text keyword match across all searchable fields. May be repeated.",
    )
    parser.add_argument(
        "--rule-id",
        action="append",
        dest="rule_id",
        help="Exact rule id match such as CMP-003 or LAY-001.",
    )
    parser.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="Output format.",
    )
    return parser.parse_args()


def load_rows(families: Iterable[str]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for family in families:
        with RULE_FILES[family].open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                row["family"] = family
                rows.append(row)
    return rows


def contains_all(text: str, needles: Iterable[str]) -> bool:
    lowered = text.lower()
    return all(needle.lower() in lowered for needle in needles)


def row_blob(row: dict[str, str]) -> str:
    return " ".join(row.get(field, "") for field in SEARCH_FIELDS)


def filter_rows(rows: list[dict[str, str]], args: argparse.Namespace) -> list[dict[str, str]]:
    filtered = rows

    if args.rule_id:
        wanted = {item.lower() for item in args.rule_id}
        filtered = [row for row in filtered if row["rule_id"].lower() in wanted]

    if args.topic:
        filtered = [
            row for row in filtered if contains_all(row.get("topic", ""), args.topic)
        ]

    if args.applies_to:
        filtered = [
            row
            for row in filtered
            if contains_all(row.get("applies_to", ""), args.applies_to)
        ]

    if args.keyword:
        filtered = [row for row in filtered if contains_all(row_blob(row), args.keyword)]

    return filtered


def as_text(rows: list[dict[str, str]]) -> str:
    if not rows:
        return "No matching rules."

    lines: list[str] = []
    for row in rows:
        lines.append(f"[{row['rule_id']}] {row['title']}")
        lines.append(f"  family: {row['family']} | topic: {row['topic']}")
        lines.append(f"  applies_to: {row['applies_to']}")
        lines.append(f"  requirement: {row['requirement']}")
        if row.get("preferred_pattern"):
            lines.append(f"  preferred: {row['preferred_pattern']}")
        if row.get("anti_pattern"):
            lines.append(f"  avoid: {row['anti_pattern']}")
        if row.get("token_refs"):
            lines.append(f"  tokens: {row['token_refs']}")
        if row.get("default_value"):
            lines.append(f"  default: {row['default_value']}")
        if row.get("notes"):
            lines.append(f"  notes: {row['notes']}")
        lines.append("")
    return "\n".join(lines).rstrip()


def main() -> int:
    args = parse_args()
    families = args.family or list(RULE_FILES)
    rows = load_rows(families)
    matches = filter_rows(rows, args)

    if args.format == "json":
        print(json.dumps(matches, ensure_ascii=False, indent=2))
    else:
        print(as_text(matches))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
