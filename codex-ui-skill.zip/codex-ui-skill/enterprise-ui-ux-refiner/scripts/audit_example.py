#!/usr/bin/env python3
"""Validate the demo page against a subset of enterprise UI rules."""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEMO_DIR = ROOT / "examples" / "element-plus-tailwind-demo" / "src" / "components"
BEFORE_FILE = DEMO_DIR / "CustomerOrdersPageBefore.vue"
AFTER_FILE = DEMO_DIR / "CustomerOrdersPageAfter.vue"


CHECKS = [
    {
        "rule_id": "FDN-001",
        "description": "Avoid hard-coded semantic colors in page implementation",
        "before_has": ["bg-[#f3f6fb]", "text-[#1f2329]", "!bg-[#245dff]"],
        "after_has": ["var(--ccui-color-primary)", "var(--ccui-color-text-primary)"],
    },
    {
        "rule_id": "FDN-006",
        "description": "Use shared spacing tokens instead of repeated literal spacing",
        "before_has": ["px-[18px]", "mr-[22px]", "mr-[18px]"],
        "after_has": ["var(--ccui-space-m)", "ccui-page-container"],
    },
    {
        "rule_id": "CMP-001",
        "description": "Set enterprise table size to medium",
        "before_has": ["<el-table :data=\"orders\""],
        "after_has": ["<el-table :data=\"orders\" size=\"medium\">"],
    },
    {
        "rule_id": "CMP-003",
        "description": "Normalize toolbar button spacing to a shared 12px gap",
        "before_has": ["mr-[6px]", "mr-[18px]", "mr-[8px]"],
        "after_has": ["ccui-table-toolbar-actions", "gap: var(--ccui-space-m);"],
    },
    {
        "rule_id": "LAY-001",
        "description": "Use the shared page safe margin",
        "before_has": ["px-[18px]"],
        "after_has": ["ccui-page-container"],
    },
    {
        "rule_id": "FDN-005",
        "description": "Use shared typography tokens for display title sizing",
        "before_has": ["text-[30px]", "leading-[38px]"],
        "after_has": ["ccui-page-title-display", "var(--ccui-font-size-xl)", "var(--ccui-line-height-xl)"],
    },
    {
        "rule_id": "LAY-004",
        "description": "Keep compact viewport safe margin explicit",
        "before_has": ["px-[18px]"],
        "after_has": ["@media (max-width: 768px)", "--ccui-space-page-compact"],
    },
]


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def main() -> int:
    before = read_text(BEFORE_FILE)
    after = read_text(AFTER_FILE)
    style = read_text(ROOT / "examples" / "element-plus-tailwind-demo" / "src" / "style.css")

    print("Audit target:")
    print(f"  before: {BEFORE_FILE}")
    print(f"  after:  {AFTER_FILE}")
    print("")

    passed = 0
    for check in CHECKS:
        before_match = all(token in before for token in check["before_has"])
        after_match = all(
            token in after or token in style
            for token in check["after_has"]
        )
        status = "PASS" if before_match and after_match else "FAIL"
        if status == "PASS":
            passed += 1
        print(f"[{status}] {check['rule_id']} {check['description']}")

    print("")
    print(f"Summary: {passed}/{len(CHECKS)} checks passed")
    return 0 if passed == len(CHECKS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
