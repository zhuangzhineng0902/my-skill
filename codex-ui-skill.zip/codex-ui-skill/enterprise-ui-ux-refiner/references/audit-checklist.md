# Audit Checklist

Run this checklist after inspecting and after patching.

## Before Editing

- Identify the page shell, shared layout, and target components.
- Locate the current source of truth for theme tokens and shared UI primitives.
- List the non-compliant patterns you expect to fix.

## After Editing

- Hard-coded visual values replaced or intentionally preserved with reason.
- Table size normalized to `medium` where applicable.
- Table toolbar button spacing normalized to `12px`.
- Page left/right safe margin normalized to `--ccui-space-l (32px)`.
- Typography and color usage mapped to enterprise tokens or documented baseline tokens.
- Business logic and behavior unchanged.
- Verification performed or explicitly skipped with reason.
