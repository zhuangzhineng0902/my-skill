# Foundation Rules

Foundation rules are now maintained in `../data/foundation-rules.csv`.

Use the CSV as the source of truth so new rules can be appended without rewriting this document. Query only the subset you need:

```bash
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family foundation --keyword color
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family foundation --topic typography
```
