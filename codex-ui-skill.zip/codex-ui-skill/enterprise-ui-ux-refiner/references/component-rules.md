# Component Rules

Component rules are now maintained in `../data/component-rules.csv`.

Use the CSV as the source of truth and retrieve only the rules needed for the current page or component:

```bash
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family component --applies-to table
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family component --applies-to toolbar --keyword spacing
```
