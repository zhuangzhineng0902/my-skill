# Global Layout Rules

Global layout rules are now maintained in `../data/global-layout-rules.csv`.

Use the CSV as the source of truth and query only the relevant layout slice:

```bash
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family layout --keyword "safe margin"
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family layout --topic responsive
```
