# CSV Rule Authoring Guide

This document explains how to extend the rule CSV files used by `enterprise-ui-ux-refiner`.

Use it when adding or updating rules in:

- `data/foundation-rules.csv`
- `data/component-rules.csv`
- `data/global-layout-rules.csv`

The goal is to keep the rule data consistent, searchable, and usable by scripts such as `query_rules.py` and `audit_vue_page.py`.

## Rule File Responsibilities

### `foundation-rules.csv`

Use this file for base design-system rules that apply across many pages or components, such as:

- Color tokens
- Typography scale
- Spacing scale
- Theme-layer refactor guidance
- Global visual primitives that should not be owned by a single component

Typical topics:

- `color`
- `typography`
- `spacing`
- `refactor`

### `component-rules.csv`

Use this file for rules tied to UI components or repeated component patterns, such as:

- Table defaults
- Toolbar layout
- Form grouping
- Card composition
- Audit questions for shared components

Typical topics:

- `table`
- `toolbar`
- `form`
- `card`
- `audit`

### `global-layout-rules.csv`

Use this file for page shell and cross-page layout rules, such as:

- Safe margins
- Shared page wrappers
- App frame spacing
- Responsive layout constraints
- Legacy layout cleanup guidance

Typical topics:

- `page-safe-margin`
- `responsive`
- `legacy`
- `refactor`

## CSV Columns

All rule CSV files currently share the same schema:

```csv
rule_id,domain,topic,title,applies_to,keywords,requirement,preferred_pattern,anti_pattern,token_refs,default_value,notes
```

### `rule_id`

Unique rule identifier.

Use these prefixes:

- `FDN-###` for foundation rules
- `CMP-###` for component rules
- `LAY-###` for layout rules

Rules:

- Must be unique within the whole skill, not only within one file.
- Keep the numeric suffix zero-padded to 3 digits.
- Do not reuse an old ID for a different meaning.

Examples:

- `FDN-009`
- `CMP-012`
- `LAY-006`

### `domain`

High-level rule family.

Allowed values for the current structure:

- `foundation`
- `component`
- `layout`

This value must match the CSV file where the rule is stored.

### `topic`

A short machine-friendly grouping label used for retrieval and audits.

Rules:

- Use lowercase.
- Prefer `kebab-case` for multi-word topics.
- Reuse an existing topic when the new rule belongs to the same concern.

Examples:

- `color`
- `typography`
- `page-safe-margin`
- `toolbar`
- `responsive`

### `title`

Short human-readable rule title.

Rules:

- One sentence fragment.
- Start with a verb when possible.
- Keep it specific enough to distinguish from neighboring rules.

Good examples:

- `Use medium as the default enterprise table size`
- `Keep adjacent toolbar button spacing at 12px`

Avoid:

- `Table rule`
- `Spacing guidance`

### `applies_to`

Short description of the surfaces or code areas where this rule applies.

Rules:

- Write for retrieval, not prose quality.
- Mention the likely targets a developer will search for.
- Keep it compact but concrete.

Good examples:

- `Table toolbars action groups`
- `Page shells content containers app frames`
- `Theme root shared layout styles`

### `keywords`

Comma-separated search terms used by scripts and developers.

Rules:

- Use lower-case keywords.
- Include synonyms a developer might search for.
- Include both UI vocabulary and implementation vocabulary when useful.
- Do not overfill the field with near-duplicates.

Good examples:

- `"toolbar,button,gap,12px,spacing"`
- `"layout,page,safe-margin,padding,32px"`
- `"font,size,line-height,weight,scale"`

### `requirement`

The core rule statement. This is the most important column.

Rules:

- Write a normative statement.
- Make the required behavior explicit.
- Prefer one main requirement per row.
- If the rule is conditional, state the condition clearly.

Good examples:

- `Default enterprise table size is medium`
- `The left and right safe margin between the page edge and the main content area must be 32px`

Avoid vague wording like:

- `Should look consistent`
- `Try to use shared styles`

### `preferred_pattern`

What developers should do when applying the rule.

Rules:

- Describe the recommended implementation direction.
- Keep it actionable.
- Prefer shared primitives, tokens, wrappers, or stable component APIs.

Good examples:

- `Use a shared toolbar wrapper or gap token to enforce consistent spacing`
- `Define or reuse the shared layout token and consume it in the page container`

### `anti_pattern`

What developers should avoid.

Rules:

- Describe the most common wrong implementation.
- Keep it implementation-oriented and concrete.
- Focus on the behavior the audit should flag.

Good examples:

- `Do not add repeated one-off left or right margins between neighboring actions`
- `Do not scatter raw hex values or arbitrary Tailwind colors in component code`

### `token_refs`

Relevant design token names or shared variables.

Rules:

- Use `|` to separate multiple token names.
- Leave blank if the rule does not map cleanly to specific tokens.
- Prefer real token names over examples if the project has already standardized them.

Examples:

- `--ccui-space-m`
- `--ccui-color-primary|--ccui-color-text-primary`

### `default_value`

The default value or baseline associated with the rule.

Rules:

- Use this only when a concrete default matters.
- Leave blank if the rule is process-oriented rather than value-oriented.
- When multiple values belong together, separate them with `|`.

Examples:

- `medium`
- `12px`
- `32px`
- `12px|14px|16px|22px|24px`

### `notes`

Extra context that helps future maintainers apply the rule correctly.

Use this for:

- Migration caveats
- Scope clarification
- Cases where the rule is advisory rather than absolute
- Follow-up hints for future automation

Good examples:

- `Tokenized gap is preferred over local margins`
- `If migration is required, document the temporary exception`
- `Use the shared page wrapper as the first choice`

## Writing Rules Well

### Prefer One Rule Per Concern

Each row should describe one rule that can be cited, queried, and eventually audited.

Do this:

- One row for table default size
- One row for toolbar gap
- One row for safe margin

Do not do this:

- One row that mixes table size, header typography, and toolbar spacing

### Keep Rules Searchable

A developer or script should be able to find a rule through:

- `topic`
- `applies_to`
- `keywords`
- `rule_id`

If a rule is hard to find, it is usually missing better `keywords` or has an overly abstract `title`.

### Prefer Reusable Guidance Over Single-Page Details

These CSV files are for reusable enterprise rules, not one-off tickets.

Good rule:

- `Use shared spacing tokens for toolbar gaps`

Too specific:

- `Set the export button margin on the customer order page to 8px`

If a requirement only applies to one page, it probably belongs in a task note, not the shared rule set.

### Encode Stable Intent

Rules should capture stable UI policy, not temporary implementation accidents.

Good:

- `Prefer shared page wrappers for consistent edge spacing`

Bad:

- `Use px-8 on all dashboard pages`

The rule should describe intent, not lock the system to a brittle implementation if a better shared primitive exists.

## When To Add A New Rule

Add a new row when:

- The rule introduces a new requirement not covered by an existing row.
- The rule needs its own `rule_id` for reporting or auditing.
- The rule has different enforcement logic from existing rows.

Update an existing row when:

- You are only clarifying wording.
- You are adding search keywords.
- You are refining notes without changing the requirement meaning.

Avoid adding a new row when:

- The new content is only an example of an existing rule.
- The change is a minor variation better captured in `notes`.

## CSV Formatting Rules

- Keep the header row unchanged unless the whole toolchain is updated.
- Preserve comma-separated CSV format.
- Quote values only when needed, such as fields containing commas.
- Do not insert markdown, bullet lists, or code blocks into CSV fields.
- Use plain text sentences.
- Use ASCII unless the existing file already requires otherwise.

## Recommended Author Workflow

1. Identify which rule family owns the new requirement.
2. Check whether an existing `topic` already fits.
3. Add a new `rule_id` with the correct prefix.
4. Fill `requirement`, `preferred_pattern`, and `anti_pattern` first.
5. Add retrieval metadata: `applies_to`, `keywords`, `token_refs`.
6. Validate retrieval using:

```bash
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --rule-id FDN-001
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family component --keyword toolbar
```

7. If the new rule should be auditable, consider extending:

- `scripts/audit_vue_page.py`
- Any example or regression demo used to verify the rule

## Examples

### Example Foundation Rule

```csv
FDN-009,foundation,shadow,Use shared elevation tokens for card shadows,Cards modals surfaces,"shadow,elevation,card,surface",Card and surface shadows should come from the shared elevation system,Reference shared elevation tokens or wrapper classes,Do not hand-tune different box-shadow values in each page,--ccui-shadow-surface,0 8px 24px rgba(31,35,41,0.08),Use when repeated surface shadows start to drift
```

### Example Component Rule

```csv
CMP-009,component,form,Keep inline form action spacing consistent,Search forms filter bars,"form,filter,actions,gap,spacing",Inline form actions should use a shared horizontal gap,Use a shared form action wrapper backed by spacing tokens,Do not manually stagger form buttons with one-off margins,--ccui-space-m,12px,Applies to filter bars and search forms
```

### Example Layout Rule

```csv
LAY-006,layout,responsive,Keep section gutters explicit on tablet layouts,Tablet page sections,"layout,tablet,responsive,gutter",Tablet layouts should define an explicit section gutter rather than inheriting desktop spacing unchanged,Use a shared responsive wrapper or tokenized gutter scale,Do not assume desktop page padding remains appropriate at tablet widths,--ccui-space-page-tablet,24px,Add only if the system has a stable tablet layout contract
```

## Suggested Maintenance Discipline

Whenever you add or change rules:

- Re-run `query_rules.py` to confirm the rule is discoverable.
- If the rule changes audit expectations, update `audit_vue_page.py`.
- If the rule changes example output, update the demo and its report.
- Keep the rule wording aligned with the actual design-system intent.

If multiple developers contribute rules over time, review new rows for:

- Duplicate meanings
- Inconsistent topic naming
- Weak or vague `requirement` text
- Missing implementation guidance in `preferred_pattern` or `anti_pattern`
