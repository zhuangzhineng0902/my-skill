---
name: enterprise-ui-ux-refiner
description: Use this skill when a Vue 3 + Tailwind internal web app does not follow enterprise UI/UX standards and needs to be audited, corrected, and normalized against design tokens, component constraints, and global layout rules. Trigger when the task is to inspect existing frontend code, identify non-compliant patterns, patch the application, and keep behavior intact while bringing the UI into spec.
---

# Enterprise UI UX Refiner

This skill repairs an existing Vue 3 + Tailwind enterprise web app so it conforms to internal UI/UX rules without changing product behavior.

Use it for refactors, audit-and-fix passes, design debt cleanup, or before handing a page to design review.

## What This Skill Does

1. Inspect the existing Vue 3 + Tailwind implementation before proposing changes.
2. Convert informal or inconsistent styling into explicit enterprise rules.
3. Patch code so screens, spacing, typography, color usage, and component composition match the spec.
4. Preserve behavior, data flow, accessibility, and existing business logic.
5. Report what changed, what remains ambiguous, and which rules were applied.

## Inputs

Expect one or more of the following:

- A Vue 3 + Tailwind codebase or one or more component files.
- Existing pages/components that visually or structurally violate the enterprise standard.
- Optional enterprise design rules, token definitions, component usage notes, or screenshots.

If the user provides only partial rules, use the bundled references in this skill as the default baseline and clearly note that assumption.

## Workflow

### 1. Inspect Before Editing

- Read the target page, shared layout wrappers, and reused components first.
- Identify whether the styling source of truth lives in Tailwind utilities, CSS variables, component props, or ad hoc inline styles.
- Search for repeated non-compliant patterns before patching a single file. Prefer fixing the shared primitive when safe.

### 2. Load Only The Relevant Rules

The structured rule source of truth lives in CSV files:

- `data/foundation-rules.csv` for colors, typography, spacing, and foundation refactor guidance.
- `data/component-rules.csv` for table, toolbar, and component audit constraints.
- `data/global-layout-rules.csv` for shell, page, and safe-area rules.
- `references/audit-checklist.md` for the fix-and-verify pass.

Use `scripts/query_rules.py` to load only the relevant rules instead of opening every rule file:

```bash
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family foundation --keyword typography
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family component --applies-to toolbar
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --keyword "safe margin"
```

Do not load every rule family by default if only one area is relevant.

### 3. Audit The Current UI Against The Rules

Check for:

- Hard-coded colors, font sizes, spacing, radii, or shadows that should be tokenized.
- Tailwind classes that conflict with enterprise defaults.
- Component sizing that violates the approved default.
- Toolbar layouts with inconsistent gaps or button grouping.
- Page containers that ignore the required left/right safe margin.
- Repeated utility patterns that should become a shared class, CSS variable, or wrapper component.

For a fast first-pass audit on a Vue page, run:

```bash
python3 enterprise-ui-ux-refiner/scripts/audit_vue_page.py path/to/Page.vue
python3 enterprise-ui-ux-refiner/scripts/audit_vue_page.py path/to/Page.vue --format json
```

Use this script to surface likely rule violations first, then load only the relevant CSV rules and patch the page deliberately.

### 4. Fix With The Lowest-Risk Change

Apply changes in this priority order:

1. Reuse existing enterprise variables, wrappers, or component props if they already exist.
2. Normalize shared primitives used by multiple screens.
3. Patch local components only when the rule is screen-specific or shared fixes would create risk.

Prefer semantic tokens and stable component APIs over one-off utility overrides.

### 5. Preserve Behavior

- Do not alter data fetching, state transitions, permissions, routing, or submit logic unless the bug is directly caused by the UI fix.
- Keep accessibility intact or improve it when touching interactive elements.
- If a visual rule conflicts with current product behavior, call out the conflict explicitly.

### 6. Verify

After editing:

- Re-read the affected files to ensure the rule is actually enforced.
- Verify spacing/token choices are consistent across the touched surface.
- Run available tests or lint checks when practical.
- Re-run `scripts/audit_vue_page.py` on the changed page to confirm the heuristic findings were removed or reduced.
- Summarize changes by rule, not just by file.

## Editing Rules

- Prefer existing CSS variables such as `--ccui-*` when available.
- If the codebase lacks the required token, add it in the closest shared theme layer instead of scattering raw values.
- Avoid mixing arbitrary Tailwind values with design tokens unless the rule explicitly requires a fixed value and no token exists.
- When replacing hard-coded spacing or dimensions, preserve layout behavior on both desktop and smaller widths.
- Keep comments rare and only where the rule application would otherwise be unclear.

## Expected Output

The result should be a corrected Vue 3 + Tailwind application, plus a concise summary covering:

- Which rule families were applied.
- Which components or layouts were normalized.
- Any unresolved ambiguity in the enterprise standard.
- What verification was or was not run.

## Example Triggers

- "Use this skill to bring this Vue 3 admin page in line with enterprise UI rules."
- "Audit these Tailwind pages and fix spacing, typography, and table toolbar layout."
- "Refactor this internal dashboard so it matches our design tokens and component constraints."
