# CSV 规则编写说明

本文档用于说明如何扩展 `enterprise-ui-ux-refiner` 使用的规则 CSV 文件。

当你需要新增或修改以下文件中的规则时，请优先阅读本文档：

- `data/foundation-rules.csv`
- `data/component-rules.csv`
- `data/global-layout-rules.csv`

目标是让规则数据保持一致、易检索、可被脚本稳定消费，例如：

- `query_rules.py`
- `audit_vue_page.py`

## 三个规则文件分别负责什么

### `foundation-rules.csv`

这个文件用于维护跨页面、跨组件的基础设计系统规则，例如：

- 色彩 token
- 字体与排版尺度
- 间距尺度
- 主题层重构原则
- 不应归属于单一组件的全局视觉基础规则

常见 `topic`：

- `color`
- `typography`
- `spacing`
- `refactor`

### `component-rules.csv`

这个文件用于维护组件级规则或重复组件模式的规则，例如：

- 表格默认规范
- 工具栏布局
- 表单编排
- 卡片结构
- 共享组件的审查问题

常见 `topic`：

- `table`
- `toolbar`
- `form`
- `card`
- `audit`

### `global-layout-rules.csv`

这个文件用于维护页面壳层和跨页面布局规则，例如：

- 安全边距
- 共享页面容器
- 应用框架间距
- 响应式布局约束
- 遗留布局清理建议

常见 `topic`：

- `page-safe-margin`
- `responsive`
- `legacy`
- `refactor`

## CSV 字段说明

当前三个规则 CSV 使用同一套字段结构：

```csv
rule_id,domain,topic,title,applies_to,keywords,requirement,preferred_pattern,anti_pattern,token_refs,default_value,notes
```

### `rule_id`

规则唯一标识。

前缀约定：

- `FDN-###` 表示基础规则
- `CMP-###` 表示组件规则
- `LAY-###` 表示布局规则

填写要求：

- 在整个 skill 范围内必须唯一，不能只在单个文件内唯一。
- 数字部分统一使用 3 位补零格式。
- 不要复用旧 ID 去表达新的规则含义。

示例：

- `FDN-009`
- `CMP-012`
- `LAY-006`

### `domain`

规则所属的大类。

当前允许值：

- `foundation`
- `component`
- `layout`

这个值必须与所在的 CSV 文件类型一致。

### `topic`

用于检索和分组的简短主题标签。

填写要求：

- 使用小写。
- 多词主题优先使用 `kebab-case`。
- 如果是已有关注点的补充规则，优先复用现有 `topic`。

示例：

- `color`
- `typography`
- `page-safe-margin`
- `toolbar`
- `responsive`

### `title`

给开发者看的简短规则标题。

填写要求：

- 尽量写成一句简短的规则描述。
- 能用动词开头就尽量用动词开头。
- 要足够具体，能和相邻规则区分开。

好的示例：

- `Use medium as the default enterprise table size`
- `Keep adjacent toolbar button spacing at 12px`

不推荐：

- `Table rule`
- `Spacing guidance`

### `applies_to`

说明这条规则主要适用于哪些界面区域、代码对象或场景。

填写要求：

- 重点是方便检索，不是写长段说明。
- 尽量写出开发者真正会搜索的对象。
- 保持简短但具体。

好的示例：

- `Table toolbars action groups`
- `Page shells content containers app frames`
- `Theme root shared layout styles`

### `keywords`

供脚本和开发者检索使用的逗号分隔关键词。

填写要求：

- 统一使用小写关键词。
- 包含开发者可能使用的同义词。
- 需要时同时覆盖 UI 术语和实现术语。
- 不要堆过多几乎重复的词。

好的示例：

- `"toolbar,button,gap,12px,spacing"`
- `"layout,page,safe-margin,padding,32px"`
- `"font,size,line-height,weight,scale"`

### `requirement`

这是一条规则最核心的字段，表示规则本身。

填写要求：

- 用明确、可执行的规范性语句描述。
- 直接写清楚要求的行为是什么。
- 一条记录尽量只表达一个主要要求。
- 如果规则有前提条件，要明确写出条件。

好的示例：

- `Default enterprise table size is medium`
- `The left and right safe margin between the page edge and the main content area must be 32px`

避免这类模糊表述：

- `Should look consistent`
- `Try to use shared styles`

### `preferred_pattern`

告诉开发者应该如何实现这条规则。

填写要求：

- 给出推荐实现方向。
- 描述要可操作。
- 优先鼓励使用共享 primitive、token、wrapper 或稳定组件 API。

好的示例：

- `Use a shared toolbar wrapper or gap token to enforce consistent spacing`
- `Define or reuse the shared layout token and consume it in the page container`

### `anti_pattern`

告诉开发者应该避免什么做法。

填写要求：

- 尽量描述最常见的错误实现方式。
- 要聚焦在实现层，而不是抽象口号。
- 最好能直接对应到审计脚本未来可能要识别的行为。

好的示例：

- `Do not add repeated one-off left or right margins between neighboring actions`
- `Do not scatter raw hex values or arbitrary Tailwind colors in component code`

### `token_refs`

与这条规则相关的设计 token 或共享变量名。

填写要求：

- 多个 token 使用 `|` 分隔。
- 如果这条规则并不直接映射到具体 token，可以留空。
- 如果项目已有正式 token 名称，优先填写真实 token 名，而不是示例名。

示例：

- `--ccui-space-m`
- `--ccui-color-primary|--ccui-color-text-primary`

### `default_value`

这条规则对应的默认值或基线值。

填写要求：

- 只有在默认值确实重要时才填写。
- 如果这条规则偏流程或策略，没有固定值，可以留空。
- 多个配套值用 `|` 分隔。

示例：

- `medium`
- `12px`
- `32px`
- `12px|14px|16px|22px|24px`

### `notes`

补充说明字段，用来写额外上下文。

适合放在这里的内容包括：

- 迁移期注意事项
- 适用范围补充
- 这条规则是强约束还是建议性约束
- 未来自动化处理时的提示

好的示例：

- `Tokenized gap is preferred over local margins`
- `If migration is required, document the temporary exception`
- `Use the shared page wrapper as the first choice`

## 如何写出高质量规则

### 一条记录只表达一个核心规则

每一行都应该是一条可以被引用、检索、审计的规则。

推荐这样拆：

- 一条写表格默认尺寸
- 一条写工具栏 gap
- 一条写页面安全边距

不要这样写：

- 一条同时混合表格尺寸、标题字号、工具栏间距

### 规则必须容易被搜到

开发者或脚本应当可以通过以下任一信息找到规则：

- `topic`
- `applies_to`
- `keywords`
- `rule_id`

如果一条规则总是搜不到，通常意味着：

- `keywords` 不够准确
- `title` 太抽象
- `applies_to` 没写清楚目标对象

### 优先写可复用规则，不要写页面私有规则

这些 CSV 文件存放的是“共享 enterprise 规则”，不是单个页面的临时需求。

好的规则：

- `Use shared spacing tokens for toolbar gaps`

不合适的规则：

- `Set the export button margin on the customer order page to 8px`

如果一个要求只适用于单个页面，它更适合写在任务说明里，而不是共享规则库里。

### 规则表达“稳定意图”，不要表达“偶然实现”

规则应描述稳定的 UI 规范意图，而不是暂时性的实现写法。

好的写法：

- `Prefer shared page wrappers for consistent edge spacing`

不好的写法：

- `Use px-8 on all dashboard pages`

应当描述目标和原则，而不是把系统锁死在脆弱的某个实现细节上。

## 什么情况下新增规则

以下情况建议新增一行：

- 新规则表达了现有记录未覆盖的新要求。
- 这条规则需要独立 `rule_id`，方便引用、审计或报告。
- 这条规则的检查逻辑与现有规则明显不同。

以下情况更适合修改现有行：

- 只是补充说明文字。
- 只是增加检索关键词。
- 只是完善备注，不改变规则本意。

以下情况不要新增一行：

- 只是现有规则的一个例子。
- 只是对现有规则轻微变体，放到 `notes` 更合适。

## CSV 填写格式要求

- 不要修改表头，除非整套工具链都同步升级。
- 保持标准逗号分隔 CSV 格式。
- 只有在字段中包含逗号时才使用引号。
- 不要在 CSV 单元格里写 Markdown、项目符号或代码块。
- 使用普通文本句子。
- 默认使用 ASCII；只有在文件现状确实需要时再引入其他字符。

## 推荐的规则维护流程

1. 先判断这个规则应该归属哪个文件。
2. 确认是否已有合适的 `topic` 可复用。
3. 生成新的 `rule_id`，并使用正确前缀。
4. 优先填写 `requirement`、`preferred_pattern`、`anti_pattern`。
5. 再补齐 `applies_to`、`keywords`、`token_refs` 等检索辅助字段。
6. 用下面命令检查规则是否能被正确检索：

```bash
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --rule-id FDN-001
python3 enterprise-ui-ux-refiner/scripts/query_rules.py --family component --keyword toolbar
```

7. 如果这条规则未来应该被自动审计到，考虑同步扩展：

- `scripts/audit_vue_page.py`
- 示例页面或回归用 demo

## 示例

### Foundation 规则示例

```csv
FDN-009,foundation,shadow,Use shared elevation tokens for card shadows,Cards modals surfaces,"shadow,elevation,card,surface",Card and surface shadows should come from the shared elevation system,Reference shared elevation tokens or wrapper classes,Do not hand-tune different box-shadow values in each page,--ccui-shadow-surface,0 8px 24px rgba(31,35,41,0.08),Use when repeated surface shadows start to drift
```

### Component 规则示例

```csv
CMP-009,component,form,Keep inline form action spacing consistent,Search forms filter bars,"form,filter,actions,gap,spacing",Inline form actions should use a shared horizontal gap,Use a shared form action wrapper backed by spacing tokens,Do not manually stagger form buttons with one-off margins,--ccui-space-m,12px,Applies to filter bars and search forms
```

### Layout 规则示例

```csv
LAY-006,layout,responsive,Keep section gutters explicit on tablet layouts,Tablet page sections,"layout,tablet,responsive,gutter",Tablet layouts should define an explicit section gutter rather than inheriting desktop spacing unchanged,Use a shared responsive wrapper or tokenized gutter scale,Do not assume desktop page padding remains appropriate at tablet widths,--ccui-space-page-tablet,24px,Add only if the system has a stable tablet layout contract
```

## 建议的维护纪律

每次新增或修改规则后，建议至少做这些事：

- 重新跑一次 `query_rules.py`，确认规则可被检索到。
- 如果规则会改变审计逻辑，同步更新 `audit_vue_page.py`。
- 如果规则会影响示例输出，同步更新 demo 和对应报告。
- 确保规则文案与真实设计系统意图一致。

如果后续多人共同维护这些规则，建议在 code review 中重点检查：

- 是否存在重复含义的规则
- `topic` 命名是否一致
- `requirement` 是否过于模糊
- `preferred_pattern` 或 `anti_pattern` 是否缺少实现指向
